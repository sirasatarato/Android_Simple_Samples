package com.silso.room

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class MailViewModelFactory(repository: InputMsgRepository) :
    ViewModelProvider.Factory {
    private var userRepository: InputMsgRepository = repository

    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return MainViewModel(userRepository) as T
    }
}
